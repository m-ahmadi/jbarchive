﻿var map;

$(document).ready(function () {
    initMap();
});

function initMap() {
    map = new MPS.Map('map');
    map.setCenter(new MPS.LonLat(DefaultX, DefaultY), DefaultZoomLevel);

    // Fix Vector API Layer Priority Issue
    map.getLayersByName('Markers')[0].setZIndex(500);
}

function drawMarkers(MarkerArray, htmlStructure) {
    if (MarkerArray.length != 0) {
        var tmpArray = [];
        var temp = '';
        for (var i = 0; i < MarkerArray.length; i++) {
            temp = htmlStructure;
            for (var j = 0; j < MarkerArray[i].htmlContent.length; j++) {
                temp = temp.replace('[' + j + ']', MarkerArray[i].htmlContent[j]);
            }
            drawMarker(MarkerArray[i].lat, MarkerArray[i].lng, MarkerArray[i].icon, temp);
            tmpArray.push([MarkerArray[i].lng, MarkerArray[i].lat]);
        }
        var polygon = map.drawPolygon(tmpArray);
        extendTo(polygon);
        polygon.destroy();
    }
}

function drawMarker(lat, lon, icon, htmlContent) {
    icon = icon || 'marker-car.png';
    var size = new MPS.Size(40, 68);
    var offset = new MPS.Pixel(-(size.w / 2), -size.h);
    var icon = new MPS.Icon('images/' + icon, size, offset);
    var marker = new MPS.Marker(new MPS.LonLat(lon, lat), icon);
    var marker = map.addMarker(marker);
    if (htmlContent) {
        //drawInfoWindow(lat, lon, htmlContent);
        marker.events.register('click', null, function () {
            alert(htmlContent);
        });
    }
}

function drawLine(pointsArray) {
    var line = map.drawLine(pointsArray);
    extendTo(line);
}

function drawLinePoint(MarkerArray, tmpPointArray, htmlStructure) {
    drawMarkers(MarkerArray, htmlStructure);
    drawLine(tmpPointArray);
}

function drawPolygon(pointsArray) {
    var polygon = map.drawPolygon(pointsArray);
    extendTo(polygon);
}

function drawInfoWindow(lat, lon, htmlContent) {
    var infoWindow = new MPS.Balloon(null, new MPS.LonLat(lon, lat), new MPS.Size(200,120), htmlContent, true);
    map.addBalloon(infoWindow);
}

function ClearMarkers() {
    // Remove All Markers
    map.clearMarkers();

    // Remove all Balloons and Popups
    for(i in map.balloons)
        map.removeBalloon(map.balloons[i]);
    for(i in map.popups)
        map.removePopup(map.popups[i]);

    // Clear the Vectors Layer
    map.getLayersByName('Vectors')[0].removeAllFeatures();
}

function extendTo(item) {
    if (item.geometry) {
        map.zoomToExtent(item.geometry.bounds)
    }
    else {
        map.setCenter(item.lonlat, 3);
    }
}

function debug() {

    //drawMarker(3956324.05, 534827.225);
    //drawMarker(3956324.05, 534827.225, null, "salaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaam");

    //drawInfoWindow(3956324, 534827, "<h1>this is a test</h1><br><p>this is a very looooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooong text</p>");

    //var tmpArray = [[534827.225, 3956324.05], [533612.825, 3956208.85], [531505.625, 3956391.25]];
    //drawLine(tmpArray);

    //var tmpArray = [[515850.425, 3955800.85], [518396.825, 3955959.25], [519894.425, 3953904.85], [521372.825, 3953828.05], [521564.825, 3952944.85], [521852.825, 3952772.05], [521776.025, 3952637.65], [520988.825, 3952772.05], [519740.825, 3952868.05], [517763.225, 3953655.25], [515850.425, 3955800.85]];
    //drawPolygon(tmpArray);

}